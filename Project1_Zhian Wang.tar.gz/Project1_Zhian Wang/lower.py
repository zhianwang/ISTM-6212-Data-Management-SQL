#!/usr/bin/env python

"""
A filter that converts input to lower case.
"""

import fileinput


def process(line):
    """For each line of input, lower the case."""
    print(line[:-1].lower())


for line in fileinput.input():
    process(line)